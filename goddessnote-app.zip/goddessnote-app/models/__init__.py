#coding:gbk
from .base_model import BaseModel
from .notebook import Notebook
from .note import Note


def create_tables():
    db = BaseModel._meta.database
    if not db.get_tables():
        db.create_tables([Notebook, Note])
    if not Notebook.select().count():
        Notebook.create(name='Ĭ�ϱʼǱ�', description='ϵͳ������Ĭ�ϱʼǱ�')
