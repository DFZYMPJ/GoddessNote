#coding:gbk
import wx
from .generic_bitmap_button import GenericBitmapButton
from models import Note
from functools import partial
from pubsub import pub

class HeaderPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent, style=wx.BORDER_NONE)
        self._init_ui()
        self.note_count = 0
        self._sort_menu_ids = wx.NewIdRef(6)
        self._checked_menu_id = self._sort_menu_ids[0]
        self.sort_option = Note.updated_at.desc()
        self._rename_notebook_menu_id = wx.NewIdRef()
        self._delete_notebook_menu_id = wx.NewIdRef()
        
        self._global_search_menu_id = wx.NewIdRef()
        self.is_global_search = False
        self._init_event()

    def _init_ui(self):
        self.main_sizer = wx.BoxSizer(wx.VERTICAL)

        self.st_notebook_name = wx.StaticText(self, label='�ʼǱ�����')
        self.main_sizer.Add(self.st_notebook_name, flag=wx.ALL, border=10)

        self._build_note_actions()
        self._build_search_bar()
        self.main_sizer.AddSpacer(10)
        self.SetSizer(self.main_sizer)

        self.SetBackgroundColour("#ebebeb")

    def _build_note_actions(self):
        note_action_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.st_note_count = wx.StaticText(self, label="10���ʼ�")
        note_action_sizer.Add(self.st_note_count)

        note_action_sizer.AddStretchSpacer()

        #self.btn_display_order_options = wx.Button(self,label='sort')
        self.btn_display_order_options = GenericBitmapButton(self,'sort')
        note_action_sizer.Add(self.btn_display_order_options)

        #self.btn_display_notebook_options = wx.Button(self, label='more')
        self.btn_display_notebook_options = GenericBitmapButton(self,'more')
        note_action_sizer.Add(self.btn_display_notebook_options,flag=wx.LEFT,border=10)

        self.main_sizer.Add(note_action_sizer, flag=wx.ALL|wx.EXPAND, border=10)
    def _build_search_bar(self):
        self.search_bar = wx.SearchCtrl(self,style=wx.TE_PROCESS_ENTER)
        self.search_bar.ShowCancelButton(True)

        search_menu = wx.Menu()
        search_menu.AppendCheckItem(wx.ID_ANY, '�������бʼǱ�')
        self.search_bar.SetMenu(search_menu)
        self.search_bar.SetHint('��������,Ӧ����Ը')

        self.main_sizer.Add(self.search_bar, flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=8)
    def set_title(self, title):
        self.st_notebook_name.SetLabel(title)

    def set_count(self, count):
        self.note_count = count
        self.st_note_count.SetLabel(f'{self.note_count}���ʼ�')

    def change_count(self, changed_count):
        self.note_count += changed_count
        self.st_note_count.SetLabel(f'{self.note_count}���ʼ�')
    def _build_action_menu(self):
        self.menu = wx.Menu()
        #self._rename_notebook_menu_id = wx.NewIdRef()
        #self._delete_notebook_menu_id = wx.NewIdRef()
        self.menu.Append(self._rename_notebook_menu_id, '�༭�ʼǱ�')
        self.menu.Append(self._delete_notebook_menu_id, 'ɾ���ʼǱ�')

        return self.menu
        
    def _build_sort_menu(self):
        menu = wx.Menu()

        sub_menu1 = wx.Menu()
        sub_menu1.AppendCheckItem(self._sort_menu_ids[0], '���µ����')
        sub_menu1.AppendCheckItem(self._sort_menu_ids[1], '��ɵ�����')
        menu.AppendSubMenu(sub_menu1, '������ʱ��')

        sub_menu2 = wx.Menu()
        sub_menu2.AppendCheckItem(self._sort_menu_ids[2], '���µ����')
        sub_menu2.AppendCheckItem(self._sort_menu_ids[3], '��ɵ�����')
        menu.AppendSubMenu(sub_menu2, '������ʱ��')

        sub_menu3 = wx.Menu()
        sub_menu3.AppendCheckItem(self._sort_menu_ids[4], '����ĸ����')
        sub_menu3.AppendCheckItem(self._sort_menu_ids[5], '��ĸ����')
        menu.AppendSubMenu(sub_menu3, '������')

        return menu
    def _init_event(self):
        self.btn_display_order_options.Bind(wx.EVT_BUTTON, self._show_sort_menu)
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.updated_at.desc()), id=self._sort_menu_ids[0])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.updated_at.asc()), id=self._sort_menu_ids[1])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.created_at.desc()), id=self._sort_menu_ids[2])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.created_at.asc()), id=self._sort_menu_ids[3])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.title.desc()), id=self._sort_menu_ids[4])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.title.asc()), id=self._sort_menu_ids[5])
        self.Bind(wx.EVT_MENU, partial(self._on_note_sorting, sort_param=Note.title.asc()), id=self._sort_menu_ids[5])
        self.btn_display_notebook_options.Bind(wx.EVT_BUTTON, self._show_action_menu)
        self.Bind(wx.EVT_MENU, lambda _: pub.sendMessage('notebook.editing'), id=self._rename_notebook_menu_id)
        self.Bind(wx.EVT_MENU, lambda _: pub.sendMessage('notebook.deleting'), id=self._delete_notebook_menu_id)
        self.search_bar.Bind(wx.EVT_TEXT, self._on_searching)
        self.Bind(wx.EVT_MENU, self._on_global_search_menu_checked, id=self._global_search_menu_id)

    def _show_sort_menu(self, _):
        menu = self._build_sort_menu()
        menu.Check(self._checked_menu_id, True)
        self.PopupMenu(menu)
        menu.Destroy()
    def _show_action_menu(self, _):
        menu = self._build_action_menu()
        self.PopupMenu(menu)
        menu.Destroy()
        
    def _on_note_sorting(self, e, sort_param):
        if self._checked_menu_id != e.GetId():
            self._checked_menu_id = e.GetId()
            self.sort_option = sort_param
            pub.sendMessage('note.sorting', sort_param=sort_param)

    def _on_searching(self, e):
        pub.sendMessage('note.searching', keyword=self.keyword, is_global_search=self.is_global_search)

    def _on_global_search_menu_checked(self, e):
        self.is_global_search = e.IsChecked()
        self._build_search_bar_menu()
        if self.keyword:
            pub.sendMessage('note.searching', keyword=self.keyword, is_global_search=self.is_global_search)
    def _build_search_bar_menu(self):
        menu = wx.Menu()
        menu.AppendCheckItem(self._global_search_menu_id, '�������бʼǱ�').Check(self.is_global_search)
        self.search_bar.SetMenu(menu)
        if self.is_global_search:
            self.search_bar.SetHint('�������бʼǱ�')
        else:
            self.search_bar.SetHint('������ǰ�ʼǱ�')

    def set_count(self, count):
        self.note_count = count
        if self.keyword:
            self.st_note_count.SetLabel(f'�ҵ�{self.note_count}���ʼ�')
        else:
            self.st_note_count.SetLabel(f'{self.note_count}���ʼ�')

    def reset_search_bar(self):
        self.search_bar.ChangeValue('')

    @property
    def keyword(self):
        return self.search_bar.GetValue().strip()
            
