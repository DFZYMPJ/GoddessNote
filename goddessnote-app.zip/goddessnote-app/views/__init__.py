#coding:gbk
from .main_frame import MainFrame
